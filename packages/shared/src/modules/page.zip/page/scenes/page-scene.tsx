import { CmsPage } from '@wpro/magento/dist/types'
import { PageLayout } from '../components/page-layout'
import { HeadingBanner } from '@scope/ui'
import { useDocument } from '@wpro/prismic'
import { CategoryListingType, EntityType } from '@scope/prismic'

interface Props {
  cmsPage: CmsPage
}

export const PageScene = ({ cmsPage }: Props) => {
  const { id, name, urlPath } = cmsPage
  const { document } = useDocument<CategoryListingType>({
    uid: `category-${urlPath}`,
    types: [EntityType.CategoryListing],
  })
  const {
    banner_title: title,
    banner_background_image: bgImage,
    banner_display_breadcrumbs: displayBreadcrumbs,
    banner_content_placement: contentPlacement,
    banner_content_alignment: alignment,
  } = document?.data ?? {}

  return (
    <PageLayout
      title={name}
      categoryId={id}
      banner={
        !bgImage?.url ? undefined : (
          <HeadingBanner
            bgImage={{ url: bgImage?.url, alt: bgImage?.alt ?? title ?? name }}
            contentPlacement={contentPlacement ?? 'center-left'}
            alignment={alignment ?? 'left'}
            displayBreadcrumbs={displayBreadcrumbs ?? true}
            title={title}
            minH="340px"
          />
        )
      }
    />
  )
}
